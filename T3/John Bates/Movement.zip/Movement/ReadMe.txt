The following Zip.file

Contains Intructions for the new behaviour as well as images that I took when making the tutroial and an explanation PowerPoint. I also included the entire unity
file