Isabel Elia's Programming Tutorial Two Submission



This submission includes:

- Tutorial2		(The actual written tutorial in a PDF format)
- Journal 		(A dated log of issues I faced whilst creating the tutorial)
- ProgrammingTask Log	(Table documenting the time spent on specific tasks for submission)
