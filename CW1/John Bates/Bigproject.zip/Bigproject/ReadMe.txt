The following Zip.file

Contains Intructions for the new behaviour as well as images that I took when making the tutroial and an explanation PowerPoint. I also included the entire unity
file. AS explained I accidently did what I had to do for all the scripts in tutorial form so they will be here in Zip form for each and everyone of them