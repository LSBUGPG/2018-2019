The following Zip.file

Contains Intructions for the new behaviour as well as images that I took when making the tutroial. I also included the entire unity
file