Isabel Elia's Programming Tutorial One Submission



This submission includes:

- TutorialText		(The actual written tutorial in a PDF format)
- Journal 		(A dated log of issues I faced whilst creating the tutorial)
- ProgrammingTask Log	(Table documenting the time spent on specific tasks for submission)
-FPSController		(Unity Project that contains a working completed version of the script)